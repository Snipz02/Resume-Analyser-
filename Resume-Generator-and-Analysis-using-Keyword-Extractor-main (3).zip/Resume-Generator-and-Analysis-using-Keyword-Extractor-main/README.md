# Resume-Generator-and-Analysis-using-Keyword-Extractor
The modern job search demands a polished and keyword-optimized resume to stand out in a sea of applicants. With plethora of resumes uploaded every single day and every second, it seems challenging to manage the data that is important for the recruitment process.
